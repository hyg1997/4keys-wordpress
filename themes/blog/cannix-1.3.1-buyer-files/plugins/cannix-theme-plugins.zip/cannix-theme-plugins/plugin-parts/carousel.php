<?php

/**
 * Template part for displaying post carousel in home() and single()
 *
 * @since 1.0
 * @version 1.1
 */

?>

<?php 

if ( is_archive() ) {
	$category = get_queried_object();
}

$order_by = ( get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_type') === 'popular' ? 'comment_count' : '' );
$post_cat = ( $position !== 'before_category' ? get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_cat' ) : $category->term_id );
$post_in = ( '' !== get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_ids' ) ? get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_ids' ) : '' );
if ( $position === 'before_category' || $position === 'related_posts' ) {
	$post_in = '';
}
$post_num = get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_num', 3 );
$row_num = get_theme_mod( '' . esc_attr( $position ) . '_carousel_rownum', 1 );
$meta_key = ( get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_type') === 'featured' ? 'cannix_featured_post' : '' );

$carousel_class = $row_num . ' ' . get_theme_mod( '' . esc_attr( $position ) . '_carousel_post_type');

 ?>

<div class="post-carousel grid<?php echo esc_attr( $carousel_class ); ?>" data-slick='{"slidesToShow": <?php echo esc_attr( $row_num ); ?>}'>
	
<?php 

// Theme slug/textDomain
$theme = wp_get_theme();
$theme_slug =  $theme->get( 'TextDomain' );

global $post;

if ( $position !== 'related_posts' ) :

	/**
	 * Post Type
	 * Category
	 * Posts Ids
	 * Number of Posts
	 * Featured
	 */

	$query_args = cannix_plugin_post_query( $order_by, $post_cat, $post_in, $post_num, $meta_key );


else :

	// Related posts

	if ( get_theme_mod( 'related_posts_carousel_method' ) !=='tags' ) {

		// Category related
		$category = get_the_category($post->ID);
		$cat_ids = array();
		foreach($category as $post_cat) {
			$cat_ids[] = $post_cat->cat_ID;
		}

		$query_args = array(
			'post__not_in' => array($post->ID),
			'post_type'      => 'post',
			'cat' => $cat_ids,
			'posts_per_page' => get_theme_mod( 'related_posts_carousel_post_num', 4 ),
		);

	} else {

		// Tags

		$tags = wp_get_post_tags($post->ID);
		$tag_ids = array();
		foreach( $tags as $post_tag ) { 
			$tag_ids[] = $post_tag->term_id;
		}

		$query_args = array(
			'post__not_in' => array($post->ID),
			'post_type'      => 'post',
			'tag__in' => $tag_ids,
			'posts_per_page' => get_theme_mod( 'related_posts_carousel_post_num', 4 ),
		);

	}

endif;

$posts_query = new WP_Query( $query_args );

    if( $posts_query->have_posts( ) ):

    /* Start the Loop */
    while ( $posts_query->have_posts( ) ) : $posts_query->the_post(); ?>

			<article <?php post_class(); ?>>

	<?php if ( has_post_format( 'gallery' ) && '' === get_the_post_thumbnail( ) ) : ?>

		<div class="post-thumbnail">

			<?php echo cannix_plugin_post_gallery( ); ?>

		</div>

	<?php else: ?>

		<div class="post-thumbnail">

			<?php if ( has_post_format( 'video' ) ) : ?>

				<span class="video-overlay"><i class="fa fa-caret-right fa-2x"></i></span>

			<?php endif; ?>

			<?php if ( has_post_format( 'audio' ) ) : ?>

				<span class="video-overlay"><i class="fa fa-headphones fa-2x"></i></span>

			<?php endif; ?>

			<a href="<?php the_permalink(); ?>">

		<?php if ( '' !== get_the_post_thumbnail() ) : ?>

					<?php
					echo cannix_plugin_query_post_thumbnail( '', '' . $theme_slug . '-carousel-image' ); ?>

		<?php else : ?>

			<img src="<?php echo get_template_directory_uri() ?>/media/<?php echo esc_attr( $theme_slug ); ?>-carousel-image-placeholder.png" alt="">

		<?php endif; ?>

			</a>
		</div><!-- .post-thumbnail -->

	<?php endif; // End if gallery ?>

	<header class="entry-header">

		<?php

		if ( 'post' === get_post_type() ) { ?>

				<div class="entry-meta post-category">
					<span class="screen-reader-text">Posted in</span><?php cannix_plugin_get_category(); ?>
				</div>

		<?php }

		the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );


		?>

		<div class="entry-meta">

			<ul>

				<?php if ( get_theme_mod( '' . esc_attr( $position ) . '_carousel_author_meta', true ) ) : ?>

				<li class="entry-author-meta">

					<span class="screen-reader-text">Posted</span>by <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"><?php echo get_the_author() ?></a>

				</li>

			<?php endif; ?>

				<?php if ( get_theme_mod( '' . esc_attr( $position ) . '_carousel_entry_date', true ) ) : ?>

				<li class="entry-date">

					<time datetime="<?php echo get_the_date( 'Y-m-d' ) ?>"><?php echo get_the_date( ) ?></time>

				</li>

			<?php endif; ?>

				<?php if ( get_theme_mod( '' . esc_attr( $position ) . '_carousel_comment_count', true ) ) : ?>

				<li class="entry-comment-count">

					<i class="fa fa-comments"></i> <?php comments_number( '0', '1', '%' ) ?>

				</li>

			<?php endif; ?>

			</ul>
	
	</div>

	</header><!-- .entry-header -->

</article><!-- #post-## -->


    <?php endwhile;

    endif;

    wp_reset_postdata(); // Always reset

 	?>

</div>