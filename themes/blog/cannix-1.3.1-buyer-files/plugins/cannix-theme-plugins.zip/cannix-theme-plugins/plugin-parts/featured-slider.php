<?php
/**
 * Template part for displaying featured slider
 *
 * @since 1.0
 * @version 1.2
 */

?>

<?php 

/**
 * Post Type
 * Category
 * Posts Ids
 * Number of Posts
 * Number of Slides to Show
 * Featured
 */

$order_by = ( get_theme_mod( 'featured_post_type') === 'popular' ? 'comment_count' : '' );
$post_cat = get_theme_mod( 'featured_post_cat', '' );
$post_in = ( '' !== get_theme_mod( 'featured_post_ids' ) ? get_theme_mod( 'featured_post_ids' ) : '' );
$post_num = get_theme_mod( 'featured_post_num', 3 );
$slide_num = get_theme_mod( 'featured_post_slidenum', 1 );
$meta_key = ( get_theme_mod( 'featured_post_type') === 'featured' ? 'cannix_featured_post' : '' );

// Image size if slidenum mod is enabled
$image_size =  ( $slide_num > 1 ? '-hero-alt-image' : '-hero-image' );
if ( get_theme_mod( 'featured_post_layout' ) === 'cover' ) {
	$image_size = '-hero-cover-image';
}

 ?>

<div class="hero slick slider <?php echo get_theme_mod( 'featured_post_layout', 'default' ); ?>" data-slides="<?php echo esc_attr( $slide_num ); ?>">
	
<?php 

// Theme slug/textDomain
$theme = wp_get_theme();
$theme_slug =  $theme->get( 'TextDomain' );

$query_args = cannix_plugin_post_query( $order_by, $post_cat, $post_in, $post_num, $meta_key );

$posts_query = new WP_Query( $query_args );

    if( $posts_query->have_posts( ) ):

    $slidecount = 0;

    /* Start the Loop */
    while ( $posts_query->have_posts( ) ) : $posts_query->the_post(); ?>

    <?php $slidecount++; ?>

    <?php if ( '' !== get_the_post_thumbnail() ) : ?>

        <div class="slide-wrapper slide-<?php echo esc_attr( $slidecount ); ?>">
        	<div class="post-thumbnail">
				<a href="<?php the_permalink(); ?>">
					<?php 
					// Check that we have the correct size image
					echo cannix_plugin_query_post_thumbnail( '', '' . $theme_slug . $image_size . '' ); ?>
				</a>
			</div>

			<div class="entry-header">

				<div class="entry-wrapper">

					<?php if ( get_theme_mod( 'featured_display_category', true )): ?>

						<div class="entry-meta post-category">
							<span class="screen-reader-text">Posted in</span> <?php cannix_plugin_get_category(); ?>
						</div><!-- .entry-meta -->

					<?php endif; ?>

			<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>

			<div class="entry-meta">

				<ul>

					<?php if ( get_theme_mod( 'featured_display_author', true)): ?>

					<li class="entry-author-meta">
					
						<?php 

						if ( get_theme_mod( 'featured_avatar', false ) ) {
							
						// author avatar
						echo get_avatar(get_the_author_meta('ID'), 40); 

						} ?>



						<span class="screen-reader-text">Posted </span>by <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ?>"><?php echo get_the_author() ?></a>
					</li>

				<?php endif; ?>

				<?php if ( get_theme_mod( 'featured_display_date', true )): ?>

					<li class="entry-date">
						<time datetime="<?php echo get_the_date( 'Y-m-d' ) ?>"><?php echo get_the_date( ) ?></time>

					</li>

				<?php endif; ?>

					<?php if ( get_theme_mod( 'featured_display_comment_count', true ) ) : ?>

					<li class="entry-comment-count">
						<i class="fa fa-comments"></i> <?php comments_number( '0', '1', '%' ) ?>
					</li>

				<?php endif; ?>
				</ul>
			</div><!-- .entry-meta -->

		</div>

			</div><!-- .entry-header -->
			<?php if ( get_theme_mod( 'featured_display_excerpt', false ) && get_theme_mod( 'featured_post_layout' ) !=='cover' ) : ?>
				<div class="entry-content">
					<?php the_excerpt(); ?>
				</div>
			<?php endif; ?>
		</div>

    <?php 

	endif; // If has post thumbnail

	endwhile;

    endif;

    wp_reset_postdata(); // Always reset

 	?>

</div>