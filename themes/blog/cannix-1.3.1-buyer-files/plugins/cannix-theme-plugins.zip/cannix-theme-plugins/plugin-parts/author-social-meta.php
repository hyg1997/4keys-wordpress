<?php
/**
 * The template for displaying the author social media meta
 *
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage cannix
 * @since 1.0
 * @version 1.1
 */

?>

<div class="author-social">
		<?php if (get_the_author_meta('cannix_author_meta_twitter')) : ?>
			<a href="https://twitter.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_twitter') ); ?>" class="twitter"><i class="fa fa-twitter"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_facebook')) : ?>
			<a href="https://facebook.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_facebook') ); ?>" class="facebook"><i class="fa fa-facebook"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_gplus')) : ?>
			<a href="https://plus.google.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_gplus') ); ?>" class="google-plus"><i class="fa fa-google-plus"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_instagram')) : ?>
			<a href="https://instagram.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_instagram') ); ?>" class="instagram"><i class="fa fa-instagram"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_youtube')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_youtube') ); ?>" class="youtube"><i class="fa fa-youtube" class="youtube"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_tumblr')) : ?>
			<a href="https://tumblr.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_tumblr') ); ?>" class="tumblr"><i class="fa fa-tumblr"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_pinterest')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_pinterest') ); ?>" class="pinterest"><i class="fa fa-pinterest"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_dribbble')) : ?>
			<a href="https://dribbble.com/<?php echo esc_attr( the_author_meta('cannix_author_meta_dribbble') ); ?>" class="dribbble"><i class="fa fa-dribbble"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_linkedin')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_linkedin') ); ?>" class="linkedin"><i class="fa fa-linkedin"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_soundcloud')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_soundcloud') ); ?>" class="soundcloud"><i class="fa fa-soundcloud"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_spotify')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_spotify') ); ?>" class="spotify"><i class="fa fa-spotify"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_medium')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_medium') ); ?>" class="medium"><i class="fa fa-medium"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_500px')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_500px') ); ?>" class="px500"><i class="fa fa-500px"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_vimeo')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_vimeo') ); ?>" class="vimeo"><i class="fa fa-vimeo"></i></a>
		<?php endif ?>
		<?php if (get_the_author_meta('cannix_author_meta_mixcloud')) : ?>
			<a href="<?php echo esc_url( the_author_meta('cannix_author_meta_mixcloud') ); ?>" class="mixcloud"><i class="fa fa-mixcloud"></i></a>
		<?php endif ?>
	</div>