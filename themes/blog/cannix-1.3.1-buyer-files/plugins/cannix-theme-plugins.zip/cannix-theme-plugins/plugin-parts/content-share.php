<?php
/**
 * Template part for displaying post share icons
 *
 * @since 1.0
 * @version 1.0
 */

?>
<?php
	// Replace spaces in the title with + symbol so we can pass it in the share link
	$strip_title = strip_tags( get_the_title() );
	$text = str_replace(' ', '%20', $strip_title );
	$text_pinterest = str_replace(' ', '+', $strip_title );
?>

<!-- share -->
<div class="share">
	<ul class="share-post">
		<li class="twitter"><a rel="nofollow" href="https://twitter.com/share?url=<?php the_permalink(); ?>&amp;text=<?php echo esc_attr( $text ); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
		<li class="facebook"><a rel="nofollow" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
		<li class="pinterest"><a rel="nofollow" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&amp;media=<?php echo get_the_post_thumbnail_url(); ?>&amp;description=<?php echo esc_attr( $text_pinterest ); ?>" target="_blank"><i class="fa fa-pinterest"></i></a></li>
		<li class="google-plus"><a rel="nofollow" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
		<li class="tumblr"><a rel="nofollow" href="https://www.tumblr.com/share/link?url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-tumblr"></i></a></li>
		<li class="reddit"><a rel="nofollow" href="https://reddit.com/submit?url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-reddit-alien"></i></a></li>
		<li class="linkedin"><a rel="nofollow" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php echo esc_attr( $text_pinterest ); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
	</ul>
</div>