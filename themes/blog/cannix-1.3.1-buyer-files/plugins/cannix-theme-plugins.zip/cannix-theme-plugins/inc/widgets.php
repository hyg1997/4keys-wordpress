<?php 

/**
 * Cannix custom widgets
 *
 *
 * @package WordPress
 * @subpackage Cannix
 * @since 1.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


// ========================================================
// Recent Posts Widget
// Displays latest or recent posts with thumbnail and meta
// ========================================================
class Cannix_Recent_Posts extends WP_Widget {

	// Setup our widget

	public function __construct() {

		$widget_ops = array(
			'classname' => 'cannix_recent_posts',
			'description' => esc_html__('Displays latest or popular posts with image thumbnail and entry meta', 'cannix'),
		);

	parent::__construct( 'cannix_recent_posts', esc_html__('Cannix: Posts Widget', 'cannix'), $widget_ops );

	}

	// Backend Display

	public function form($instance) {

		/* Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$number = (!empty($instance['number']) ? absint($instance['number'] ) : 4);
		$post_type = (!empty($instance['post_type']) ? $instance['post_type'] : 'recent');
		$post_cat = (!empty($instance['post_cat']) ? $instance['post_cat'] : '');
		$post_ids = (!empty($instance['post_ids']) ? $instance['post_ids'] : '');
		$layout = (!empty($instance['layout']) ? $instance['layout'] : '');

		// Widget admin form

		// Title
		$output = '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('title') ) . '">' . esc_html__('Title:', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('title')) . '" name="' . esc_attr($this->get_field_name('title')) . '" value="' . esc_attr($title) . '">';
		$output .= '</p>';

		// Number of Posts
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('number') ) . '">' . esc_html__('Number of Posts:', 'cannix') . '</label>';
		$output .= '<input type="number" class="widefat" id="' . esc_attr($this->get_field_id('number')) . '" name="' . esc_attr($this->get_field_name('number')) . '" value="' . esc_attr($number) . '">';
		$output .= '</p>';

		// Post Type
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_type') ) . '">' . esc_html__('Post Type:', 'cannix') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('post_type')) . '" name="' . esc_attr($this->get_field_name('post_type')) . '">';
		$output .= '<option ' . selected( $post_type, 'recent', false ) . ' value="recent">' . esc_html__('Recent', 'cannix') . '</option>';
		$output .= '<option ' . selected( $post_type, 'popular', false ) . ' value="popular">' . esc_html__('Popular', 'cannix') . '</option>';

		if ( function_exists( 'cannix_featured_post_meta' ) ) :
			$output .= '<option ' . selected( $post_type, 'featured', false ) . ' value="featured">' . esc_html__('Featured', 'cannix') . '</option>';
		endif;
		
		$output .= '</select>';
		$output .= '</p>';

		// Category ID
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_cat') ) . '">' . esc_html__('Category: (Can be used with Post Type)', 'cannix') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('post_cat')) . '" name="' . esc_attr($this->get_field_name('post_cat')) . '">';
		$output .= '<option></option>'; // Set a blank option if selected we'll just display the latest posts

		// Category selection
		$categories = get_categories('type=post');
		foreach($categories as $category) {
			if ($category->term_id == $post_cat) {
			$output .= '<option selected="selected" value="' . $category->term_id . '">' . $category->cat_name . '</option>';
			} else {
				$output .= '<option value="' . $category->term_id . '">' . $category->cat_name . '</option>';
			}
		}
		$output .= '</select>';
		$output .= '</p>';

		// Specific post IDs
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('post_ids') ) . '">' . esc_html__('Post IDs: (Enter a comma separated List of post IDs)', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('post_ids')) . '" name="' . esc_attr($this->get_field_name('post_ids')) . '" value="' . esc_attr($post_ids) . '">';
		$output .= '</p>';

		// Layout
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('layout') ) . '">' . esc_html__('Layout:', 'cannix') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('layout')) . '" name="' . esc_attr($this->get_field_name('layout')) . '">';
		$output .= '<option ' . selected( $layout, 'list', false ) . ' value="list">' . esc_html__('List', 'cannix') . '</option>';
		$output .= '<option ' . selected( $layout, 'list-first-grid', false ) . ' value="list-first-grid">' . esc_html__('List First Grid', 'cannix') . '</option>';
		$output .= '<option ' . selected( $layout, 'grid', false ) . ' value="grid">' . esc_html__('Grid', 'cannix') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Escape the output
		$allowed_html = array(
			'p' => array(),
			'label' => array(
				'for' => array(),
			),
			'input' => array(
				'type' => array(),
				'class' => array(),
				'id' => array(),
				'name' => array(),
				'value' => array(),
				'checked' => array(),
			),
			'textarea' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'select' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'option' => array(
				'value' => array(),
				'selected' => array(),
			),
			'button' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
		);

		echo wp_kses( $output, $allowed_html );

	}

	// Update Widget

	public function update($new_instance, $old_instance) {

		$instance = array();
		$instance['title'] = (!empty($new_instance['title']) ? strip_tags($new_instance['title']) : '');
		$instance['number'] = (!empty($new_instance['number']) ? absint(strip_tags($new_instance['number'])) : 4);
		$instance['post_type'] = (!empty($new_instance['post_type']) ? strip_tags($new_instance['post_type']) : '');
		$instance['post_cat'] = (!empty($new_instance['post_cat']) ? strip_tags($new_instance['post_cat']) : '');
		$instance['post_ids'] = (!empty($new_instance['post_ids']) ? strip_tags($new_instance['post_ids']) : '');
		$instance['layout'] = (!empty($new_instance['layout']) ? strip_tags($new_instance['layout']) : '');

		return $instance;

	}

	// Front End Display

	public function widget($args, $instance) {

		$number = (!empty($instance['number']) ? absint($instance['number']) : 4);
		$order_by = ( $instance[ 'post_type' ] === 'popular' ? 'comment_count' : '');
		$meta_key = ( $instance[ 'post_type' ] === 'featured' ? 'cannix_featured_post' : '' );
		$post_cat = ( !empty($instance['post_cat']) ? $instance['post_cat'] : '' );
		$post_in = ( '' !== $instance['post_ids'] ? $instance['post_ids'] : '' );

		/**
		 * Post type
		 * Category
		 * Post Ids
		 * Number of posts
		 * Featured
		 */

		$query_args = cannix_post_query( $order_by, $post_cat, $post_in, $number, $meta_key );

		$posts_query = new WP_Query($query_args);

		// Escape the widget output
		$allowed_html = array(
			'section' => array(
				'class' => array(),
				'id'  => array(),
			),
			'h2' => array(
				'class' => array(),
			),
		);
		echo wp_kses( $args['before_widget'], $allowed_html );

		if (!empty( $instance[ 'title' ])) :
			echo wp_kses( $args['before_title'], $allowed_html ) . apply_filters( 'widget_title', $instance['title'] ) . wp_kses( $args['after_title'], $allowed_html );
		endif;

		if($posts_query->have_posts()):

			$count = 0;

			echo '<ol class="list-style-' . $instance[ 'layout' ] . ' ' . $instance[ 'post_type' ] . '-posts">';

		while ($posts_query->have_posts()) : $posts_query->the_post();

			$count++;

			if ( $count === 1 && $instance[ 'layout' ] === 'list-first-grid' ) {
				// First full width
				get_template_part( 'template-parts/post/content', 'sidebar-grid' );

			} else {

				if ( $instance[ 'layout' ] === 'grid') {

					get_template_part( 'template-parts/post/content', 'sidebar-grid' );

				} else {

		           get_template_part( 'template-parts/post/content', 'sidebar' );

		       }

	       }

        endwhile;

        	echo '</ol>';

		endif;

		echo wp_kses( $args['after_widget'], $allowed_html );

		wp_reset_postdata(); // Always reset
	}

} // End Cannix_Recent_Posts Class

add_action('widgets_init', function() {
	register_widget( 'Cannix_Recent_Posts' );
});

// ========================================================
// About Widget
// Image, title and description with optional social media
// ========================================================

class Cannix_About_Me extends WP_Widget {

	// Setup our widget

	public function __construct() {

		// Add Widget scripts
   		add_action('admin_enqueue_scripts', array($this, 'scripts'));

		$widget_ops = array(
			'classname' => 'widget_about',
			'description' => esc_html__('Display about me widget with image, title and description', 'cannix'),
		);

	parent::__construct( 'widget_about', esc_html__('Cannix: About Me Widget', 'cannix'), $widget_ops );

	}

	// Backend Display

	public function form($instance) {

		/* Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$description = (!empty($instance['description']) ? $instance['description'] : '');
		$image = (!empty ($instance['image']) ? $instance['image'] : '');
		$background = (!empty ($instance['background']) ? $instance['background'] : '');
		$show_social = (isset($instance['show_social']) ? (bool) $instance['show_social'] : false);

		// Widget admin form

		// Title
		$output = '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('title') ) . '">' . esc_html__('Title:', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('title')) . '" name="' . esc_attr($this->get_field_name('title')) . '" value="' . esc_attr($title) . '">';
		$output .= '</p>';

		// Description
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('description') ) . '">' . esc_html__('About Me:', 'cannix') . '</label>';
		$output .= '<textarea class="widefat" id="' . esc_attr($this->get_field_id('description')) . '" name="' . esc_attr($this->get_field_name('description')) . '">';
		$output .= esc_attr( $description );
		$output .= '</textarea>';
		$output .= '</p>';

		// Image
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('image') ) . '">' . esc_html__('Avatar Image:', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('image')) . '" name="' . esc_attr($this->get_field_name('image')) . '" value="' . esc_url($image) . '">';
		$output .= '<button class="upload_image_button button button-primary">' . esc_html__('Select Image:', 'cannix') . '</button>';
		$output .= '</p>';

		// Background
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('background') ) . '">' . esc_html__('Background Image:', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('background')) . '" name="' . esc_attr($this->get_field_name('background')) . '" value="' . esc_url($background) . '">';
		$output .= '<button class="upload_image_button button button-primary">' . esc_html__('Select Image:', 'cannix') . '</button>';
		$output .= '</p>';

		// Show Social Media Icons
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('show_social') ) . '">' . esc_html__('Show Social Media Links', 'cannix') . '</label>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $show_social, 1, false ) . ' id="' . esc_attr($this->get_field_id('show_social')) . '" name="' . esc_attr($this->get_field_name('show_social')) . '">';
		$output .= '</p>';

		// Escape the output
		$allowed_html = array(
			'p' => array(),
			'label' => array(
				'for' => array(),
			),
			'input' => array(
				'type' => array(),
				'class' => array(),
				'id' => array(),
				'name' => array(),
				'value' => array(),
				'checked' => array(),
			),
			'textarea' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'button' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
		);

		echo wp_kses( $output, $allowed_html );

	}

	// Update Widget

	public function update($new_instance, $old_instance) {

		$instance = array();
		$instance['title'] = (!empty($new_instance['title']) ? strip_tags($new_instance['title']) : '');
		$instance['description'] = (!empty ($new_instance['description']) ? $new_instance['description'] : '');
		$instance['image'] = (!empty ($new_instance['image']) ? $new_instance['image'] : '');
		$instance['background'] = (!empty ($new_instance['background']) ? $new_instance['background'] : '');
		$instance['show_social'] = (isset( $new_instance['show_social'] ) ? (bool) $new_instance['show_social'] : false);

		return $instance;

	}

	// Front End Display

	public function widget($args, $instance) {

		// Escape the output
		$allowed_html = array(
			'section' => array(
				'class' => array(),
				'id'  => array(),
			),
			'h2' => array(
				'class' => array(),
			),
		);


		echo wp_kses( $args['before_widget'], $allowed_html );

		// Background

		if (!empty( $instance['background'])) :
			echo '<div class="about-background" style="background: url(' . esc_url( $instance['background'] ) . ')"></div>';
		endif;

		// Image

		if (!empty( $instance['image'])) :
			echo '<div class="about-avatar" style="background: url(' . esc_url( $instance['image'] ) . ')"></div>';
		endif;

		// Title
		if (!empty( $instance[ 'title' ])) :
			echo wp_kses( $args['before_title'], $allowed_html ) . apply_filters('widget_title', $instance['title']) . wp_kses( $args['after_title'], $allowed_html );
		endif;

		// Description
		if(!empty($instance['description'])) :

			echo '<p>' . $instance['description'] . '</p>';

		endif;

		if (!empty($instance['show_social'])) :

			echo '<div class="widget widget_social">';

			cannix_show_social_icons();

			echo '</div>';

		endif;

		echo wp_kses( $args['after_widget'], $allowed_html );

	}

	// Finally our scripts function for the image upload

	public function scripts() {
	    wp_enqueue_script( 'media-upload' );
	    wp_enqueue_media();
	    wp_enqueue_script('cannix_admin', get_template_directory_uri() . '/js/admin.js', array('jquery'));
	}

} // End Cannix_About_Me Class

add_action('widgets_init', function() {
	register_widget( 'Cannix_About_Me' );
});

// ========================================================
// Social Widget
// Displays social media links and icons populated from
// Social Media Settings
// ========================================================

class Cannix_Social_Widget extends WP_Widget {

	// Setup our widget

	public function __construct() {

		$widget_ops = array(
			'classname' => 'widget_social',
			'description' => esc_html__('Displays links and Icons of all your social media channels from Social media Settings', 'cannix'),
		);

	parent::__construct( 'cannix_social', esc_html__('Cannix: Social Widget', 'cannix'), $widget_ops );

	}

	// Backend Display

	public function form($instance) {

		/* Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$show_text = ( isset($instance['show_text']) ? (bool) $instance['show_text'] : false );

		// Widget admin form

		// Title
		$output = '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('title') ) . '">' . esc_html__('Title:', 'cannix') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('title')) . '" name="' . esc_attr($this->get_field_name('title')) . '" value="' . esc_attr($title) . '">';
		$output .= '</p>';

		// Show social media text
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('show_text') ) . '">' . esc_html__('Show Social Media Name:', 'cannix') . '</label>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $show_text, 1, false ) . ' id="' . esc_attr($this->get_field_id('show_text')) . '" name="' . esc_attr($this->get_field_name('show_text')) . '">';
		$output .= '</p>';

		// Let the user know that they can't change the social options here but they can edit them in the settings panel

		$output .= '<p>' . esc_html__('You can update the social media channels displayed in this widget in the Social Media Settings of the Customizer', 'cannix') . '</a>';


		// Escape the output
		$allowed_html = array(
			'p' => array(),
			'label' => array(
				'for' => array(),
			),
			'input' => array(
				'type' => array(),
				'class' => array(),
				'id' => array(),
				'name' => array(),
				'value' => array(),
				'checked' => array(),
			),
			'textarea' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'button' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
		);

		echo wp_kses( $output, $allowed_html );

	}

	// Update Widget

	public function update($new_instance, $old_instance) {

		$instance = array();
		$instance['title'] = (!empty($new_instance['title']) ? strip_tags($new_instance['title']) : '');
		$instance['show_text'] = (isset( $new_instance['show_text'] ) ? (bool) $new_instance['show_text'] : false);

		return $instance;

	}

	// Front End Display

	public function widget($args, $instance) {

		$show_text = ( $instance['show_text'] ? true : false );

		// Escape the output
		$allowed_html = array(
			'section' => array(
				'class' => array(),
				'id'  => array(),
			),
			'h2' => array(
				'class' => array(),
			),
		);


		echo wp_kses( $args['before_widget'], $allowed_html );

		// Title
		if (!empty( $instance[ 'title' ])) :
			echo wp_kses( $args['before_title'], $allowed_html ) . apply_filters('widget_title', $instance['title']) . wp_kses( $args['after_title'], $allowed_html );
		endif;

		cannix_show_social_icons( $show_text ); // See functions.php

		echo wp_kses( $args['after_widget'], $allowed_html );

	}


} // End Cannix_Social_Widget Class

add_action('widgets_init', function() {
	register_widget( 'Cannix_Social_Widget' );
});