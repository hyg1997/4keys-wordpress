<?php
/**
 * Cannix admin functions and definitions
 *
 *
 * @package WordPress
 * @subpackage Cannix
 * @since 1.0
 * @version 1.0
 */

/**
 * Sets up admin functions (mostly meta boxes that control style and visual elements)
 * These settings override all global colour scheme settings/changes
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// ========================================================
// Article Colour Picker
// ========================================================

//  Enqueue the color picker scripts
 
if ( ! function_exists( 'cannix_color_picker_scripts' ) ) {

	function cannix_color_picker_scripts( $hook ) {
		wp_enqueue_style( 'wp-color-picker');
		wp_enqueue_script( 'wp-color-picker');
		// We already enqueue admin.js for our widgets so no need to enqueue again here

	}

}

add_action( 'admin_enqueue_scripts', 'cannix_color_picker_scripts');

// ========================================================
// Background Color
// ========================================================

// Background Colour Meta Box
 
if ( ! function_exists( 'cannix_add_bgcolor_meta_box' ) ) {

	function cannix_add_bgcolor_meta_box() {

		add_meta_box(
			'article-custom-background-colour',
			esc_html__('Article Background Colour', 'cannix' ),
			'cannix_article_background_meta_box',
			'post',
			'side',
			'low'
		);

	}
}

add_action( 'add_meta_boxes', 'cannix_add_bgcolor_meta_box' );

// Callback
	
if ( ! function_exists( 'cannix_article_background_meta_box' ) ) {

	function cannix_article_background_meta_box( $post ) {

		$custom = get_post_custom( $post->ID );
		$article_bgcolour = ( isset( $custom['article_bgcolour'][0] ) ) ? $custom['article_bgcolour'][0] : '';
		wp_nonce_field( 'cannix_article_background_meta_box', 'cannix_article_background_meta_box_nonce' );

		?>

		<div class="pagebox">
		    <p><?php echo esc_html__( 'Choose a background colour for this post', 'cannix' ); ?></p>
		    <input class="cannix_color_field" type="text" name="article_bgcolour" value="<?php echo esc_attr( $article_bgcolour, 'cannix' ); ?>" />
		</div>
		<?php

	}

}

// Save it
	
if ( ! function_exists( 'cannix_save_bgcolor_meta_box' ) ) {

	function cannix_save_bgcolor_meta_box( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id )) {
			return;
		}
		if ( !isset( $_POST['article_bgcolour'] ) || ! wp_verify_nonce( $_POST['cannix_article_background_meta_box_nonce'], 'cannix_article_background_meta_box' ) ) {
			return;
		}
		$article_bgcolour = (isset($_POST['article_bgcolour']) && $_POST['article_bgcolour']!='') ? $_POST['article_bgcolour'] : '';
		update_post_meta($post_id, 'article_bgcolour', $article_bgcolour);
	}

}
 
add_action( 'save_post', 'cannix_save_bgcolor_meta_box' );

// ========================================================
// Entry Font Color
// ========================================================

// Font Colour Meta Box
 
if ( ! function_exists( 'cannix_add_entrycolor_meta_box' ) ) {

	function cannix_add_entrycolor_meta_box() {

		add_meta_box(
			'article-custom-entry-colour',
			esc_html__('Article Entry Font Colour', 'cannix' ),
			'cannix_article_entrycolor_meta_box',
			'post',
			'side',
			'low'
		);

	}
}

add_action( 'add_meta_boxes', 'cannix_add_entrycolor_meta_box' );

// Callback
	
if ( ! function_exists( 'cannix_article_entrycolor_meta_box' ) ) {

	function cannix_article_entrycolor_meta_box( $post ) {

		$custom = get_post_custom( $post->ID );
		$article_entrycolour = ( isset( $custom['article_entrycolour'][0] ) ) ? $custom['article_entrycolour'][0] : '';
		wp_nonce_field( 'cannix_article_entrycolor_meta_box', 'cannix_article_entrycolor_meta_box_nonce' );

		?>

		<div class="pagebox">
		    <p><?php echo esc_html__( 'Choose entry font colour for this post', 'cannix' ); ?></p>
		    <input class="cannix_color_field" type="text" name="article_entrycolour" value="<?php echo esc_attr( $article_entrycolour, 'cannix' ); ?>" />
		</div>
		<?php

	}

}

// Save it
	
if ( ! function_exists( 'cannix_save_entrycolor_meta_box' ) ) {

	function cannix_save_entrycolor_meta_box( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id )) {
			return;
		}
		if ( !isset( $_POST['article_entrycolour'] ) || ! wp_verify_nonce( $_POST['cannix_article_entrycolor_meta_box_nonce'], 'cannix_article_entrycolor_meta_box' ) ) {
			return;
		}
		$article_entrycolour = (isset($_POST['article_entrycolour']) && $_POST['article_entrycolour']!='') ? $_POST['article_entrycolour'] : '';
		update_post_meta($post_id, 'article_entrycolour', $article_entrycolour);
	}

}
 
add_action( 'save_post', 'cannix_save_entrycolor_meta_box' );

?>