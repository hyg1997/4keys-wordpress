<?php

/**
Plugin Name: Cannix Theme Plugins
Plugin URI:  http://www.3forty.media
Description: Essential plugin functions to beautify your Theme.
Version:     1.3
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

---

Just a bunch of simple functions that add a bit of eye candy
and desirable features to our theme. None are required but
the theme is designed to be used with them. Not all functions
are used in all themes.
HTML output is located in plugin-parts folder

*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'CANNIX__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// ========================================================
// Enqueue scripts and styles
// ========================================================

// ========================================================
// Add author social media links to the user admin
// We'll use these in author displays in single posts
// ========================================================

function cannix_author_social( $method ) {

	// Add new fields
	$method['cannix_author_meta_twitter'] = esc_html__( 'Twitter Username', 'threeforty' );
	$method['cannix_author_meta_facebook'] = esc_html__( 'Facebook Username', 'threeforty' );
	$method['cannix_author_meta_gplus'] = esc_html__( 'Google Plus', 'threeforty' );
	$method['cannix_author_meta_instagram'] = esc_html__( 'Instagram Username', 'threeforty' );
	$method['cannix_author_meta_youtube'] = esc_html__( 'YouTube Full URL', 'threeforty' );
	$method['cannix_author_meta_tumblr'] = esc_html__( 'Tumblr Username', 'threeforty' );
	$method['cannix_author_meta_pinterest'] = esc_html__( 'Pinterest Full URL', 'threeforty' );
	$method['cannix_author_meta_dribbble'] = esc_html__( 'Dribbble Username', 'threeforty' );
	$method['cannix_author_meta_linkedin'] = esc_html__( 'Linkedin Full URL', 'threeforty' );
	$method['cannix_author_meta_soundcloud'] = esc_html__( 'Soundcloud Full URL', 'threeforty' );
	$method['cannix_author_meta_spotify'] = esc_html__( 'Spotify Full URL', 'threeforty' );
	$method['cannix_author_meta_medium'] = esc_html__( 'Medium Full URL', 'threeforty' );
	$method['cannix_author_meta_500px'] = esc_html__( '500px Full URL', 'threeforty' );
	$method['cannix_author_meta_vimeo'] = esc_html__( 'Vimeo Full URL', 'threeforty' );
	$method['cannix_author_meta_mixcloud'] = esc_html__( 'Mixcloud Full URL', 'threeforty' );

	return $method;
}

add_filter('user_contactmethods', 'cannix_author_social');

// ========================================================
// Display Author Social Meta
// ========================================================
function cannix_author_social_meta() {

	include( CANNIX__PLUGIN_DIR . 'plugin-parts/author-social-meta.php' );

}

// ========================================================
// Really Simple Social share for posts archive and single
// ========================================================

function cannix_share_post(  ) {

	include( CANNIX__PLUGIN_DIR . 'plugin-parts/content-share.php' );

}

// ========================================================
// Post Slider built on Slick
// ========================================================
function cannix_featured_slider( ) {

	include( CANNIX__PLUGIN_DIR . 'plugin-parts/featured-slider.php' );

}

// ========================================================
// Post Carousel built on Slick
// ========================================================
function cannix_post_carousel( $position = '' ) {

	include( CANNIX__PLUGIN_DIR . 'plugin-parts/carousel.php' );

}

// ========================================================
// Additional Customizer settings
// ========================================================
function cannix_customizer_settings( ) {

	// We just need to know that it's registered so we can output the relevant customizer options
	return true;
	
}

// ========================================================
// Include additional files and functions
// ========================================================

include( CANNIX__PLUGIN_DIR . 'inc/widgets.php' );
include( CANNIX__PLUGIN_DIR . 'inc/functions-admin.php' );


// ========================================================
// Output the related category links in post meta
// ========================================================
/**
 * This function only exists to handle Many category EDGE case
 */

function cannix_plugin_get_category() {

	global $post;

	$category = get_the_category($post->id);
	$limit = 2;
	$count = 0;

	foreach($category as $the_category) {

		$count++;

			echo '<span class="category-link-bg"><a href="' . get_category_link( $the_category->cat_ID ) . '">' . $the_category->cat_name . '</a></span>';

			// Seperators are added via CSS with the :after pseudo element

			// Break if we have more then 2 categories
			if ( count( $category ) > $limit && $count == $limit ) {
				echo ' . . .';
				break;
			}
		}

}

// ========================================================
// Check we have the specified media size for post loops
// ========================================================

function cannix_plugin_query_post_thumbnail( $img_url = '', $image_size ) {

	global $post;

	global $_wp_additional_image_sizes; 

	// Theme slug/textDomain
$theme = wp_get_theme();
$theme_slug =  $theme->get( 'TextDomain' );

	// The size required by theme
	$required_width = $_wp_additional_image_sizes['' . esc_attr( $image_size ) . '']['width'];
	$required_height = $_wp_additional_image_sizes['' . esc_attr( $image_size ) . '']['height'];

	// Query string to check
	$size_string = $required_width . 'x' . $required_height;

	$thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), esc_attr( $image_size ) );
	$thumbnail_url = $thumbnail_src[0];

	// Do we have a match
	if ( strpos( $thumbnail_url, $size_string ) ) {

	    	return the_post_thumbnail( $image_size );

	} else {

		$background_image = ('' !== $img_url ? esc_url( $img_url ) : get_the_post_thumbnail_url() );

		$output = '<img src="' . get_template_directory_uri() . '/media/' . esc_attr( $image_size ) . '-placeholder.png" alt="">';
		$output .= '<div class="thumbnail-background" style="background: url(' . esc_url( $background_image ) . ')"></div>';
		
			return $output;

	}

}

// ========================================================
// Grab the first image in a gallery for archive/carousel
// ========================================================

function cannix_plugin_post_gallery( ) {

	global $post;

	// Theme slug/textDomain
	$theme = wp_get_theme();
	$theme_slug =  $theme->get( 'TextDomain' );

	$post_attachment_ids = '';
	$gallery_ids['ids'] = '';

	// Fetch all the galleries for this post
	preg_match_all( '#\[gallery\s*.*?\]#s', get_the_content(), $galleries );

		foreach ($galleries as $gallery_array) {

			foreach ($gallery_array as $gallery) {

				if (strpos($gallery,'ids=') === false) {

					// This gallery has no ID's, fetch the images attached to the post instead
					$attachments = get_posts( array(
			            'post_type' => 'attachment',
			            'posts_per_page' => -1,
			            'post_parent' => $post->ID,             
			        ) );

			        if ( $attachments ) {
			            foreach ( $attachments as $attachment ) {

			                $post_attachment_ids .= ',' . $attachment->ID;

			            }
		        	}

				} else {

					// We do have IDs
					$gallery_ids = get_post_gallery( get_the_ID(), false );

				}
			}
		}

	// Create an array and filter only unique values
	$ids = explode( ",", $gallery_ids['ids'] . ',' . $post_attachment_ids );

	$unique_ids = array_unique($ids);

	$gallery_img = '';

	foreach( $unique_ids as $id ) {

		// Only numeric IDs
		if ( absint($id) ) {

				$img = wp_get_attachment_image( $id, '' . $theme_slug  . '-carousel-image' );
				$img_url = wp_get_attachment_image_url( $id, '' . $theme_slug  . '-carousel-image' );

	    		// We output the gallery image as a background for archive lists just in case we don't have the corrrect size image

    			$gallery_img .= '<a href="' . get_the_permalink() . '">' . cannix_query_post_thumbnail( $img_url, '' . $theme_slug  . '-carousel-image') . '</a>';

		    	// Break after the first foreach (we don't run gallery in the carousel)

		    	break;


		}

	} 

	return $gallery_img;

}

// ========================================================
// A global post query function, simply return the results
// ========================================================
/* This saves having to duplicate the same query for 
 * widgets, sliders and carousels inside template files
 */

function cannix_plugin_post_query( $order_by = '', $post_cat = '', $post_in = '', $post_num = 4, $meta_key = '' ) {

	if ( '' !== $post_in ) {

		// Specific posts create an array
		$post_in = explode(',', $post_in );

		$query_args = array(
		    'posts_per_page' => $post_num,
		    'post__in' => $post_in,
		    'ignore_sticky_posts' => 1,
		    'orderby' => 'post__in',
		    'meta_query' => array(array('key' => '_thumbnail_id')), // With thumbnail
		);

	} else {

		$query_args = array(
		    'posts_per_page' => $post_num,
		    'cat' => $post_cat,
		    'meta_key' => $meta_key, // Featured Popsts
			'meta_value' => 1,
		    'ignore_sticky_posts' => 1,
		    'orderby' => $order_by, // Popular
		    'meta_query' => array(array('key' => '_thumbnail_id')), // With thumbnail
		);

	}

return $query_args;

}

// ========================================================
// Admin function Add Featured Post META Box
// ========================================================
/**
 * This adds another post type we can use for our
 * sliders, carousels and widgets
 */

function cannix_featured_post_meta() {

	add_meta_box(
		'featured_post',
		esc_html__( 'Featured Post', 'threeforty' ),
		'cannix_featured_post_callback',
		'post',
		'side',
		'low'
		);

}

add_action( 'add_meta_boxes', 'cannix_featured_post_meta' );

function cannix_featured_post_callback( $post ) {

	wp_nonce_field(basename( __FILE__ ), 'cannix_featured_post_meta_nonce' );

		$value = get_post_meta( $post->ID, 'cannix_featured_post', true );

		echo '<label for="cannix_featured_post">';
		if ($value == '') {
			echo ' <input id="cannix_featured_post" name="cannix_featured_post" type="checkbox" class="checkbox">';
		} else {
			echo ' <input id="cannix_featured_post" name="cannix_featured_post" type="checkbox" class="checkbox" checked="checked">';
		}
		echo esc_html__( 'Featured Post', 'threeforty' );
		echo '</label>';

}

function cannix_save_featured_post_data( $post_id ) {

	// Return if meta-box doesnt exist
	if ( ! isset( $_POST['cannix_featured_post_meta_nonce'] ) ) {
		return;
	}
	// Return if nonce is not valid
	if ( ! wp_verify_nonce( $_POST['cannix_featured_post_meta_nonce'], basename( __FILE__ ))) {
		return;
	}
	// Return if doing and autosave
	if ( defined( 'DOING_AUTOAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Return if user does not have permisson
	if ( ! current_user_can( 'edit_post', $post_id )) {
		return;
	}

	$featured_checkbox = '';

	if (isset($_POST['cannix_featured_post']))
    {
        $featured_checkbox = 1;
    } 

	update_post_meta( $post_id, 'cannix_featured_post', $featured_checkbox );
}

add_action( 'save_post', 'cannix_save_featured_post_data' );

?>