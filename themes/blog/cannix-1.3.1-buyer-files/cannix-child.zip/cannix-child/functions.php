<?php
/**
 * Cannix CHILD THEME functions and definitions
 *
 *
 * @package WordPress
 * @subpackage Cannix
 * @since 1.0
 */

// ========================================================
// Add your own functions and customisations
// ========================================================
function cannix_child_scripts() {
	wp_enqueue_style( 'cannix-parent-style', get_parent_theme_file_uri() . '/style.css', array(), null );
	wp_enqueue_style( 'cannix-child-style', get_stylesheet_directory_uri() . '/style.css', array(), null );
}
add_action( 'wp_enqueue_scripts', 'cannix_child_scripts' );
